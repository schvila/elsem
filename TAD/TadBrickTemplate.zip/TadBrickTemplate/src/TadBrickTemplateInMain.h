// Copyright (c) 1995-TEMPLATE_COPYRIGHT by FEI Company. All rights reserved.

#pragma once

class CTadBrickTemplateDLLApp : public CWinApp
{
public:
	virtual BOOL InitInstance( );
	virtual int ExitInstance( );
};

extern CTadBrickTemplateDLLApp theTadBrickTemplateApp;

#define FACILITY 1024
