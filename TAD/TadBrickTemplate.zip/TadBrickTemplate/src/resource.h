//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TadBrickTemplate.rc
//
#define IDB_BRICK                       1
#define IDB_ELEMENT                     2
#define IDM_ABOUTBOX                    100
#define IDS_PROJNAME                    101
#define IDS_ABOUTBOX                    102
#define IDI_ELEMENT                     103
#define IDR_MAINFRAME                   1000
#define IDR_REGISTRY1                   1001
#define IDS_STRING_5V                   1002
#define IDS_STRING_15V                  1003
#define IDS_STRING_NEG15V               1004
#define IDS_STRING_24V                  1005
#define IDS_STRING_CONN                 1006
#define IDS_STRING_12V                  1007
#define IDS_OK                          1024
#define IDS_FAILED                      1025
#define IDS_SUCCESS                     1026
#define IDS_ACTION                      1027
#define IDS_RESULT                      1028
#define IDS_CONFIRM_DESCR1              1029
#define IDS_VERSION                     1029
#define IDS_TOOLID                      1030
#define IDS_START                       1090
#define IDS_SKIPPED                     1101
#define IDS_WARNING                     1102
#define IDS_Step0                       1103
#define IDS_Step1                       1104
#define IDD_INSPECTION_DIALOG           1600
#define IDC_ISD_SETVALUE                2001
#define IDC_ISD_SIMULATE_EVENT          2002
#define IDC_ISD_EVENTCOMBO              2003
#define IDC_ISD_STATE1                  2004
#define IDC_ISD_STATE2                  2005
#define IDC_ISD_FLAG1                   2006
#define IDC_ISD_FLAG2                   2007
#define IDC_ISD_OUTPUT                  2008
#define IDC_ISD_CLEAROUTPUT             2009
#define IDC_ISD_OUTPUTLEVEL_1           2010
#define IDC_ISD_OUTPUTLEVEL_2           2011
#define IDC_ISD_OUTPUTLEVEL_3           2012
#define IDC_ISD_OUTPUTLEVEL_4           2013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1003
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2014
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
